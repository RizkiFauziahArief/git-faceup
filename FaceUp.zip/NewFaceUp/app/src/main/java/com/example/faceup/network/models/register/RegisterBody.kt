package com.example.faceup.network.models.register

data class RegisterBody(
    val nama : String,
    val email : String,
    val password : String
)
