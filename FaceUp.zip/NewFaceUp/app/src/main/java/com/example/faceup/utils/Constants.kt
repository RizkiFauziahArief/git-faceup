package com.example.faceup.utils

object Constants {
    const val MY_PACKAGE = "com.example.faceup"
}