package com.example.faceup.network.models.login

data class LoginBody(
    val email:String,
    val password:String
)
