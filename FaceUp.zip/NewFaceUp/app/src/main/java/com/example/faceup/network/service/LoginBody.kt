package com.example.faceup.network.service

import retrofit2.http.Body


//data class LoginBody(
//    @Body
//)
